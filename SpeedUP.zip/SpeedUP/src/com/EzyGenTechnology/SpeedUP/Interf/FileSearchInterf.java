
package com.EzyGenTechnology.SpeedUP.Interf;

import java.io.File;

import javax.swing.JFrame;

import org.slf4j.Logger;


/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
*/

public interface FileSearchInterf {
 public void fileSearch(String inputType, Logger logger,String filePath, File destDir,JFrame frame);
}
