
package com.EzyGenTechnology.SpeedUP.Interf;

import javax.swing.JFrame;

import org.slf4j.Logger;

import com.EzyGenTechnology.SpeedUP.Pojo.GitResponse;

/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
*/

public interface GitCodeInterf {
	
	GitResponse getGitCode(String inputType, Logger logger,String filePath,JFrame frame,String gitFlag);

}
