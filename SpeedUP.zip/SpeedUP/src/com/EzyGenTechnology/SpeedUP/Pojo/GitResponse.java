package com.EzyGenTechnology.SpeedUP.Pojo;

import java.io.File;
/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
*/
public class GitResponse {
	File  destiDirectory;
	String directoryPath;
	public File getDestiDirectory() {
		return destiDirectory;
	}
	public void setDestiDirectory(File destiDirectory) {
		this.destiDirectory = destiDirectory;
	}
	public String getDirectoryPath() {
		return directoryPath;
	}
	public void setDirectoryPath(String directoryPath) {
		this.directoryPath = directoryPath;
	}
	
	

}
