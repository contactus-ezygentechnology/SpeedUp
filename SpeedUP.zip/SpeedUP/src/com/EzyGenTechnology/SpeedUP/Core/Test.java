
package com.EzyGenTechnology.SpeedUP.Core;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
*/

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File destDir=new File("D:\\SpeedUP");
		try {
		destDir.mkdir();
		}catch(Exception ex) {
			
		}
		System.out.println("Done...!");
		//copyDir("C:\\SpeedUP\\SpeedUP\\ShabiPOS","C:\\SpeedUP\\SpeedUP\\Test",true);
	}
	
	private static void copyDir(String src, String dest, boolean overwrite) {
	    try {
	        Files.walk(Paths.get(src)).forEach(a -> {
	            Path b = Paths.get(dest, a.toString().substring(src.length()));
	            try {
	                if (!a.toString().equals(src))
	                    Files.copy(a, b, overwrite ? new CopyOption[]{StandardCopyOption.REPLACE_EXISTING} : new CopyOption[]{});
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        });
	    } catch (IOException e) {
	        //permission issue
	        e.printStackTrace();
	    }
	}

}
