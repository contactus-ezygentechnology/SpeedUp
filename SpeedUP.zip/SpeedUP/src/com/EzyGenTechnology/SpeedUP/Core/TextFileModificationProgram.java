package com.EzyGenTechnology.SpeedUP.Core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
 */
public class TextFileModificationProgram
{    
	static void modifyFile(String filePath, String oldString, String newString, org.slf4j.Logger logger)
	{
		File fileToBeModified = new File(filePath);

		String oldContent = "";

		BufferedReader reader = null;

		FileWriter writer = null;

		int NumberOfRetries = 3;
		int DelayOnRetry = 1000;


		try
		{
			reader = new BufferedReader(new FileReader(fileToBeModified));

			//Reading all the lines of input text file into oldContent

			String line = reader.readLine();

			while (line != null) 
			{
				oldContent = oldContent + line + "\n";

				line = reader.readLine();
			}


			String newContent=oldContent;


			//Replacing oldString with newString in the oldContent
			if(oldContent.contains(oldString)==true) {
				logger.info("'"+oldString+"\'"+" IN FILE:"+filePath+" IS GOING TO BE REPLACED WITH '"+newString+"'");
				newContent = oldContent.replaceAll(oldString, newString);
			}

			//Rewriting the input text file with newContent

			for (int i=1; i <= NumberOfRetries; ++i) {

				try {
					// Do stuff with file
					writer = new FileWriter(fileToBeModified);

					break; // When done we can break loop
				}
				catch (IOException e)  {
					// You may check error code to filter some exceptions, not every error
					// can be recovered.
					try {
						Thread.sleep(DelayOnRetry);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}

			writer.write(newContent);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				//Closing the resources

				reader.close();
				if (writer!=null)
					writer.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}


}