
package com.EzyGenTechnology.SpeedUP.Core;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.yaml.snakeyaml.Yaml;

import com.EzyGenTechnology.SpeedUP.Interf.FileSearchInterf;

/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
*/

public class FileSearchImpl {
	
	void fileSearch(String inputTypeString1, Logger logger1, String filePath1, File destDir1,JFrame frame1) {
		
		FileSearchInterf fileSearchImpl=(String inputTypeString, Logger logger,String filePath,File destDir,JFrame frame)->{
			Map<String, Object> obj=null;
			FileSearchCore fileSearch = new FileSearchCore();
			Map<String,String> map =new HashMap<>();
			JSONParser jsonParser= new JSONParser();
			
			try {
				
				Yaml yaml=new Yaml();

				FileReader reader= new FileReader(filePath);
				logger.info("****************************Welcome to SpeedUP Tool************");

				if(inputTypeString.equalsIgnoreCase("yaml")) {
					logger.info("Going to read git configuration from "+filePath);
					obj=yaml.load(reader);
				}else {
					logger.info("Going to read git configuration from "+filePath);
					obj=(Map<String,Object>) jsonParser.parse(reader);
				}
				
				Iterator keys= obj.keySet().iterator();
				
				while(keys.hasNext()) {
					
					String currentDynamicKey = (String)keys.next();
					
					fileSearch.searchDirectory(destDir, currentDynamicKey, obj.get(currentDynamicKey).toString());
					int count= fileSearch.getResult().size();
					if(count==0) {
						logger.info("No result found in the File Name");
					}else {
						logger.info(" Found "+count+" result");
						for(String matched : fileSearch.getResult()) {
							logger.info(" Found: "+matched);
						}
					}
					
				}
				
			}catch(Exception e) {
				
				logger.info(e.getMessage());
				JOptionPane.showMessageDialog(frame, "Please check SpeedUP logs for the error "+e.getMessage());
				e.printStackTrace();
				System.exit(0);
				
			}
			
					
			
		};
		
		fileSearchImpl.fileSearch(inputTypeString1, logger1, filePath1, destDir1, frame1);
	}
	

}
