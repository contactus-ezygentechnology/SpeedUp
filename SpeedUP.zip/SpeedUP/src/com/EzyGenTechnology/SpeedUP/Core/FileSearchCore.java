package com.EzyGenTechnology.SpeedUP.Core;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;


/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
 */

public class FileSearchCore {

	public static Logger logger = (Logger) LoggerFactory.getLogger(FileSearchCore.class);
	private String fileNameToSearch;
	private List<String> result = new ArrayList<String>();

	public String getFileNameToSearch() {
		return fileNameToSearch;
	}

	public void setFileNameToSearch(String fileNameToSearch) {
		this.fileNameToSearch = fileNameToSearch;
	}

	public List<String> getResult() {
		return result;
	}

	/* public static void main(String[] args) {

		FileSearchCore fileSearch = new FileSearchCore();

	        //try different directory and filename :)
		fileSearch.searchDirectory(new File("E:\\Candour-Git\\esoft\\src\\main\\java\\com\\esoft\\pos"), "discountMapping","discountmapping");

		int count = fileSearch.getResult().size();
		if(count ==0){
		    System.out.println("\nNo result found!");
		}else{
		    System.out.println("\nFound " + count + " result!\n");
		    for (String matched : fileSearch.getResult()){
			System.out.println("Found : " + matched);
		    }
		}
	  }*/

	public void searchDirectory(final File directory, final String fileNameToSearch, final String newName) {

		setFileNameToSearch(fileNameToSearch);

		if (directory.isDirectory()) {			
			
			search(directory,newName);
		} else {
			System.out.println(directory.getAbsoluteFile() + " is not a directory!");
		}

	}

	private void search(final File file, final String newName) {

		if (file.isDirectory()) {
			logger.info("Searching directory ... " + file.getAbsoluteFile() +" .Directory Name "+file.getName());
			if(file.getName().equalsIgnoreCase(getFileNameToSearch())) {
				logger.info("Matched directoryName " + file.getAbsoluteFile() +" . Changed to "+file.getName());
				
				File newDir = new File(file.getParent() + "\\" + newName);
				file.renameTo(newDir);
				
			}

			//do you have permission to read this directory?	
			if (file.canRead()) {
				for (File temp : file.listFiles()) {
					if (temp.isDirectory()) {
						if(!temp.getName().equals(".git")) {
							search(temp,newName);
						}
						
					} else {

						logger.info("Going to scan file...!"+temp.getName());
						TextFileModificationProgram.modifyFile(temp.getAbsolutePath().toString(), getFileNameToSearch(), newName, logger);
						if(temp.getName().contains(getFileNameToSearch())) {
							System.out.println("Absolute Path "+temp.getAbsolutePath().toString());

							String newFile=replaceLast(temp.getAbsolutePath().toString(), getFileNameToSearch(), newName);

							logger.info("New File Path" +newFile);

							File oldfile= new File(temp.getAbsolutePath().toString());
							File newfile= new File(newFile);
							try {

								if(oldfile.renameTo(newfile)) {
									logger.info("rename Successful");

								}else {
									logger.info("Rename failed");
								}

							}catch(Exception ex) {
								ex.printStackTrace();
							}

							this.result.add(temp.getAbsolutePath().toString());
						}


					}
				}

			} else {
				System.out.println(file.getAbsoluteFile() + "Permission Denied");
			}
		}

	}

	public static String replaceLast(final String string,final String toReplace,final String replacement) {
		int pos = string.lastIndexOf(toReplace);
		if(pos>-1) {
			return string.substring(0, pos) + replacement + string.substring(pos + toReplace.length(),string.length());

		}else {
			return string;
		}

	}

}
