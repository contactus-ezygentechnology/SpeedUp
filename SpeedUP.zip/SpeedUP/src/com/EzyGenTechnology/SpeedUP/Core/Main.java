
package com.EzyGenTechnology.SpeedUP.Core;

import java.io.File;
import java.io.FileReader;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import com.EzyGenTechnology.SpeedUP.Pojo.GitResponse;


/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
 */

public class Main {

	/**
	 * @param args
	 */

	public static Logger logger=LoggerFactory.getLogger(Main.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame = new JFrame("Result");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		String inputTypeString="";
		String gitFlag="";
		GitResponse gitResponse=null;

		String destinationDirectoryPath ="";
		File destDir=null;

		logger.info("***************Welcome to SpeedUP Tool******************************************");
		JSONParser jsonParser= new JSONParser();

		try {

			FileReader inputType = new FileReader("C:\\speedUP-main\\speedUP-main\\configuration\\inputType.yaml");
			//FileReader inputType = new FileReader("/Users/speedUP-main/speedUP-main/configuration/inputType.yaml");
			Yaml yaml = new Yaml();
			GitCodeImpl getGitHubCode= new GitCodeImpl();
			FileSearchImpl fileSearchImpl = new FileSearchImpl();
			Map<String,Object> inputMap = yaml.load(inputType);
			inputTypeString=inputMap.get("inputType").toString();
			Iterator keys = inputMap.keySet().iterator();
			gitFlag=inputMap.get("gitFlag").toString();
			
			
			
			logger.info("gitFlag is "+gitFlag);

			while(keys.hasNext()) {
				String currencyDynamicKey = (String)keys.next();

				logger.info("currencyDynamicKey>>>"+currencyDynamicKey);
				logger.info("Value>>>"+inputMap.get(currencyDynamicKey).toString());
				if(currencyDynamicKey.contains("file")) {
					String [] fileName=inputMap.get(currencyDynamicKey).toString().split(",");
					gitResponse=getGitHubCode.getFromGit(inputTypeString, logger, "c:\\speedUP-main\\speedUP-main\\configuration\\"+fileName[0], frame,gitFlag);
					//gitResponse=getGitHubCode.getFromGit(inputTypeString, logger, "/Users/speedUP-main/speedUP-main/configuration/"+fileName[0], frame,gitFlag);

					destDir=gitResponse.getDestiDirectory();
					destinationDirectoryPath=gitResponse.getDirectoryPath();
					fileSearchImpl.fileSearch(inputTypeString, logger, "c:\\speedUP-main\\speedUP-main\\configuration\\"+fileName[1],destDir, frame);
					//fileSearchImpl.fileSearch(inputTypeString, logger, "/Users/speedUP-main/speedUP-main/configuration/"+fileName[1],destDir, frame);

				}
			}


		}catch(Exception e) {
			logger.info(e.getMessage());
			JOptionPane.showMessageDialog(frame, "Please check speedUP api log for the error: "+e.getMessage());
			e.printStackTrace();
			System.exit(0);


		}

		JOptionPane.showMessageDialog(frame, "Completed successfully. Please find your code at "+destinationDirectoryPath);
		System.exit(0);


	}

}
