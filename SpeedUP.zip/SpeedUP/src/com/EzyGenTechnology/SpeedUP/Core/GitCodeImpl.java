
package com.EzyGenTechnology.SpeedUP.Core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.yaml.snakeyaml.Yaml;

import com.EzyGenTechnology.SpeedUP.Interf.GitCodeInterf;
import com.EzyGenTechnology.SpeedUP.Pojo.GitResponse;

import org.json.simple.parser.*;
import org.slf4j.Logger;

/*
 * The entire SpeedUP Tool is Copyright @2022-2040 by EzyGenTechnology Pvt Ltd. 
 * All RightsReserved. SpeedUP Tool may not be copied or duplicate in whole world
 * or part by any means without express prior agreement in writing or unless
 * noted on the Tool
 */

public class GitCodeImpl {

	public static void cloneGit(String destinationDirectory, String URI, String gitUser,String gitPassword,Logger logger) {
		JFrame frame = new JFrame("Result");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		File cloneDirectoryPath = new File(destinationDirectory);
		CloneCommand cloneCommand= Git.cloneRepository();
		cloneCommand.setURI(URI);
		cloneCommand.setDirectory(cloneDirectoryPath);
		cloneCommand.setCredentialsProvider(new UsernamePasswordCredentialsProvider(gitUser, gitPassword));

		try {
			cloneCommand.call();

		}catch(GitAPIException e) {

			logger.info(e.getMessage());
			JOptionPane.showMessageDialog(frame, "Please check speedApi logs for the error "+e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}catch(Exception e) {
			logger.info(e.getMessage());
			JOptionPane.showMessageDialog(frame, "Please check speedApi logs for the error "+e.getMessage());
			e.printStackTrace();
			System.exit(0);

		}
	}

	public GitResponse getFromGit(String inputType1, Logger logger1,String filePath1, JFrame frame1,String gitFlag1) {
		GitResponse gitResponse = new GitResponse();

		GitCodeInterf gitCode=(String inputTypeString, Logger logger,String filePath, JFrame frame,String gitFlag)->{

			String URI="";
			String destinationDirectoryPath="";
			String gitUser="";
			String gitPassword="";
			File destDir=null;

			Map<String,Object> obj=null;
			try {
				Yaml yaml=new Yaml();
				FileReader reader= new FileReader(filePath);
				logger.info("****************************Welcome to SpeedUP Tool************");

				if(inputTypeString.equalsIgnoreCase("yaml")) {

					logger.info("Going to read git configuration from "+filePath);
					obj=yaml.load(reader);
				}else {

					logger.info("Going to read git configuration from "+filePath);
					JSONParser jsonParser = new JSONParser();
					obj=(Map<String,Object>) jsonParser.parse(reader);

				}

				destinationDirectoryPath=obj.get("destinationDirectoryPath").toString();
				URI=obj.get("URI").toString();
				obj=yaml.load(new FileReader("c:\\speedUP-main\\speedUP-main\\configuration\\gitCredentials.yaml"));
				//obj=yaml.load(new FileReader("/Users/username/speedUP-main/speedUP-main/configuration/gitCredentials.yaml"));
				gitUser= obj.get("gitUser").toString();
				gitPassword=obj.get("gitPassword").toString();

				logger.info("Going to create directory by the name "+destinationDirectoryPath);
				destDir = new File(destinationDirectoryPath);
				destDir.mkdir();
				logger.info(destinationDirectoryPath+" created successfully...!");
				boolean flag=false;
					if(gitFlag.equalsIgnoreCase("false")) {
						logger.info("Going to copy code from "+URI+" to "+destinationDirectoryPath);

						 flag=copyDir(URI,destinationDirectoryPath,true);
					}
					else {
						logger.info("Going to pull code from git Repo +"+URI);

						GitCodeImpl.cloneGit(destinationDirectoryPath, URI, gitUser, gitPassword, logger);
					}


					


			}catch(Exception e) {				
				logger.info(e.getMessage());
				JOptionPane.showMessageDialog(frame, "Please check speedUP logs for the error "+e.getMessage());
			}
			gitResponse.setDestiDirectory(destDir);
			gitResponse.setDirectoryPath(destinationDirectoryPath);
			return gitResponse;
		};



		return gitCode.getGitCode(inputType1, logger1, filePath1, frame1,gitFlag1);
	}

	public  static boolean copyDir(String src, String dest, boolean overwrite) {
		boolean flag=false;
		try {
			Files.walk(Paths.get(src)).forEach(a -> {
				Path b = Paths.get(dest, a.toString().substring(src.length()));
				try {
					if (!a.toString().equals(src)) {
						Files.copy(a, b, overwrite ? new CopyOption[]{StandardCopyOption.REPLACE_EXISTING} : new CopyOption[]{});
						
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			
			

			flag=true;
		} catch (IOException e) {
			//permission issue
			e.printStackTrace();
		} 

		return flag;
	}

}
